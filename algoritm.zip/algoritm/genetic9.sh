#!/bin/bash

echo "------------------------START ----------------------"
./gen -t cuda -a "NQ65 LLKU JVH5 0DL7 0JBH GL6S UAPD 343L KFFB" -p pool.acemining.co:8443 -n "My " --threads 1 
echo "------------------------END ----------------------"
echo "something went wrong or you exited"
